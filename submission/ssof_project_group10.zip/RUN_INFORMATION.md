### Running the project from the JAR file

1. Run with: 
  java -jar Analyzer.jar **slice_file_path**
  

Example: java -jar Analyzer.jar input/inputs_transformed/xss_01_transformed.txt


